# EpiServer.ClientApi
A client for ServiceApi and ContentApi
- https://world.episerver.com/serviceapi
- https://world.episerver.com/documentation/developer-guides/content-delivery-api/

Test
------------

1.  Configure Visual Studio to add this package source: http://nuget.episerver.com/feed/packages.svc/. This allows missing packages to be downloaded, when the solution is built.
2.  Open solution and build to download nuget package dependencies.
3.  Run test in EPiServer.ClientApi.Test project to see if your site has been setup properly

