﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EpiServer.ClientApi
{
	public class SiteContext
	{
		public string IntegrationUrl;
		public string UserName;
		public string Password;
	}
}
